package com.gamingroom.gameauth.auth;

import io.dropwizard.auth.Authorizer;

public class GameAuthorizer implements Authorizer<GameUser> 
{
	// Checks to see if user is authorized to perform certain actions
    @Override
    public boolean authorize(GameUser user, String role) {
 
       return user.getRoles() != null && user.getRoles().contains(role);
       }
    }