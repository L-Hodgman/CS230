package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game, player, and team identifier
	 */
	private static long nextGameId = 1;
	private static long nextPlayerId = 1;
	private static long nextTeamId = 1;

	/*
	 * New GameService instance stored in service
	 */
	private static GameService service = null;
	
	/*
	 * Constructor prevents more than one instance of GameService object
	 */
	private GameService() {
		
	}
	
	// Looks for existing GameService instance
	// If new instance, stores in service
	public static GameService getInstance() {
		if (service == null) {
			service = new GameService();
		}
		return service;
	}
	 
	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {

		// A local game instance
		Game game = null;

		// Game instance iterator
		Iterator<Game> gamesIterator = games.iterator();
		
		// Iterates over list of existing games	
		while (gamesIterator.hasNext()) {
			
			// Sets instance with next item
			Game gameInstance = gamesIterator.next();
			
			// If name exists - returns game instance
			if(gameInstance.getName().equals(name)) {
				return gameInstance;
			}
		}
		
		// If name doesn't exist, adds game to list and creates a new instance
		if(game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}
		
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// A local game instance
		Game game = null;
		
		// Game instance iterator
		Iterator<Game> gamesIterator = games.iterator();
		
		// Iterates over list existing games
		while(gamesIterator.hasNext()) {
			
			// Sets next item to local variable
			Game gameInstance = gamesIterator.next();
			
			// If game id exists, returns instance
			if(gameInstance.getId() == id) {
				return gameInstance;
			}
		
		}

		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		// Game instance iterator
		Iterator<Game> gamesIterator = games.iterator();
		
		// Iterates over list existing games
		while(gamesIterator.hasNext()) {
			
			// Sets next item to local variable
			Game gameInstance = gamesIterator.next();
			
			// If game exists, returns instance
			if(gameInstance.getName().equals(name)) {
				game = gameInstance;
			}
		}
		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
	
	// Returns next player's id
	public long getNextPlayerId() {
		return nextPlayerId++;
	}
	
	// Returns next team's id
	public long getNextTeamId() {
		return nextTeamId++;
	}
}
