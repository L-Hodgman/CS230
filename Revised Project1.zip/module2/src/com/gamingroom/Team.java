package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Team extends Entity{
	
	// Creates a list of active players - Players go into teams
	private List<Player> players = new ArrayList<Player>();
	
	/*
	 * Constructor with an identifier and name
	 */
	public Team(long id, String name) {
		super(id, name);
	}

	public Player addPlayer(String name) {
		// A local player instance
		Player player = null;
		
		// Instance iterator
		Iterator<Player> playersIterator = players.iterator();
		
		// Iterates over list of players
		while(playersIterator.hasNext()) {
			
			// Next list item set to local instance
			Player playerInstance = playersIterator.next();
			
			// If player exists, returns instance
			if(playerInstance.getName().equals(name)) {
				player = playerInstance;
			}
			// If player not found = new player
			else {
				player = null;
			}
		}
		
		// If player is new, add to list
		if(player == null) {
			players.add(player);
		}
		
		return player;
	}

	@Override
	public String toString() {
		return "Team [id=" + this.getId() + ", name=" + this.getName() + "]";
	}
}
