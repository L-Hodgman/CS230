package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 * 
 * @author coce@snhu.edu
 *
 */

public class Game extends Entity {
	
	// Creates a list of active teams - Teams go into games
	private List<Team> teams = new ArrayList<Team>();
	
	/**
	 * Constructor with an identifier and name
	 */
	public Game(long id, String name) {
		super(id, name);
	}
	
	public Team addTeam(String name) {
		// A local team instance
		Team team = null;
		
		// Instance iterator
		Iterator<Team> teamsIterator = teams.iterator();
		
		// Iterates over existing list of teams
		while(teamsIterator.hasNext()) {
			
			// Next list item set to local instance
			Team teamInstance = teamsIterator.next();
			
			// If team exists, returns instance
			if(teamInstance.getName().equals(name)) {
				team = teamInstance;
			}
			// If team not found = new team
			else {
				team = null;
			}
		}
		
		// If team is new, add to list
		if(team == null) {
			teams.add(team);
		}
		
		return team;
	}

	@Override
	public String toString() {
		
		return "Game [id=" + this.getId() + ", name=" + this.getName() + "]";
	}

}
